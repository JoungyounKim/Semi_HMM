

omija=matrix(scan("omija.txt"),ncol=57,byrow=T)
p=length(omija[,1])
omija=omija[21:(p-20),]
#
#실험의 초기와 끝 부분의 일부 자료를 버렸습니다. 제가 아는 바에 의하면 이렇게 
#해야 합니다. 
#

#nomija=omija
#
nomija=log(1+omija) 
# 의 변환을 할 지 논의 하여 보아야 할 듯 합니다. 우선은 원자료를 가지고 하여 주십시요.
#


for(i in (1:57)){
	nomija[,i]=omija[,i]/sum(omija[,i])
}
#
# 위의 절차는 표준화 작업입니다. 
#

com=nomija[,1:27]
kom=nomija[,38:57]

p=length(com[,1])
tstat=rep(0,p)

for(j in (1:p)){
	tstat[j]=t.test(com[j,],kom[j,])$statistic 
}

hist(tstat,nclass=200)

