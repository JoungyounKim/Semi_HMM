

omija=matrix(scan("omija.txt"),ncol=57,byrow=T)
p=length(omija[,1])
omija=omija[21:(p-20),]
#
#실험의 초기와 끝 부분의 일부 자료를 버렸습니다. 제가 아는 바에 의하면 이렇게 
#해야 합니다. 
#


#nomija=omija
#

for(i in (1:57)){
	nomija[,i]=omija[,i]/sum(omija[,i])
}
#
# 위의 절차는 표준화 작업입니다. 
#

nomija=log(1+omija) 
# 의 변환을 할 지 논의 하여 보아야 할 듯 합니다. 우선은 원자료를 가지고 하여 주십시요.
#



com=nomija[,1:27]
kom=nomija[,38:57]

p=length(com[,1])
tstat=rep(0,p)

for(j in (1:p)){
	tstat[j]=t.test(com[j,],kom[j,])$statistic 
}

hist(tstat,nclass=200)


#
# The estimation of the empirical null usning "fitdist" funtion 
#
library(fitdistrplus)

#
# length=3189 
#

low=floor(3189*0.1)
upp=floor(3189*0.9)

nullstat=sort(tstat)[low:upp]

fitdist(nullstat,dtnorm,"mle",start=list(mean=mean(nullstat),sd=sd(nullstat)),
fix.arg=list(a=nullstat[1],b=nullstat[2553]))


> fitdist(nullstat,dtnorm,"mle",start=list(mean=mean(nullstat),sd=sd(nullstat)),
+ fix.arg=list(a=nullstat[1],b=nullstat[2553]))

#
# Fitting of the distribution ' tnorm ' by maximum likelihood 
# Parameters:
#       estimate Std. Error
# mean -3.836857 0.04355508
# sd    1.704329 0.05110388
# Fixed parameters:
#        value
# a -6.4556017
# b -0.9429213
#

m=-3.836
s=1.704

newstat=(tstat-m)/s

hist(newstat,nclass=200)
